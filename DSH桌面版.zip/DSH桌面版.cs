// DSH 桌面版 + AI 哨兵  (single-file C# .NET Framework 4.x, C# 5 compatible)
// DeepSeek Harness desktop launcher / guardian:
//   - boots `dsh web` as a child process, captures real-time logs (incl. plugin
//     install output and load-time errors) into files and a live window
//   - watchdog: health probes, profile-state change detection, automatic
//     restore points, and automatic rollback when a plugin change is followed
//     by a crash / unresponsive boot
//   - modes:  (default) windowed supervisor ;  --guard tray-only watchdog ;
//             --selftest [outfile] headless engine self test
#define TRACE
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

// ---------------------------------------------------------------------------
// Tiny flat-JSON reader/writer (only string/number/bool scalars, one per line)
// ---------------------------------------------------------------------------
public class FlatConfig
{
    private readonly Dictionary<string, string> _m = new Dictionary<string, string>();

    public static string NormalizeDir(string p)
    {
        if (string.IsNullOrEmpty(p)) return p;
        return p.TrimEnd('\\') + "\\";
    }

    private static string Unescape(string s)
    {
        if (s == null) return s;
        StringBuilder sb = new StringBuilder(s.Length);
        for (int i = 0; i < s.Length; i++)
        {
            char c = s[i];
            if (c == '\\' && i + 1 < s.Length)
            {
                char n = s[i + 1];
                if (n == '\\') { sb.Append('\\'); i++; }
                else if (n == '"') { sb.Append('"'); i++; }
                else if (n == 'n') { sb.Append('\n'); i++; }
                else if (n == 't') { sb.Append('\t'); i++; }
                else if (n == '/') { sb.Append('/'); i++; }
                else sb.Append(c);
            }
            else sb.Append(c);
        }
        return sb.ToString();
    }

    private static string Escape(string s)
    {
        StringBuilder sb = new StringBuilder(s.Length + 8);
        foreach (char c in s)
        {
            if (c == '\\') sb.Append("\\\\");
            else if (c == '"') sb.Append("\\\"");
            else if (c == '\n') sb.Append("\\n");
            else if (c == '\t') sb.Append("\\t");
            else if (c == '\r') { }
            else sb.Append(c);
        }
        return sb.ToString();
    }

    public static FlatConfig Load(string path)
    {
        FlatConfig cfg = new FlatConfig();
        if (!File.Exists(path)) return cfg;
        Regex rx = new Regex("^\\s*\"([A-Za-z0-9_]+)\"\\s*:\\s*(\"(.*)\"|true|false|-?\\d+)\\s*,?\\s*$",
            RegexOptions.Compiled | RegexOptions.Singleline);
        foreach (string rawLine in File.ReadAllLines(path, Encoding.UTF8))
        {
            string line = rawLine.Trim();
            if (line.Length == 0 || line.StartsWith("//") || line.StartsWith("#")) continue;
            Match m = rx.Match(line);
            if (m.Success)
            {
                string key = m.Groups[1].Value;
                string val;
                if (m.Groups[2].Value.StartsWith("\"")) val = Unescape(m.Groups[3].Value);
                else val = m.Groups[2].Value;
                cfg._m[key] = val;
            }
        }
        return cfg;
    }

    public string GetStr(string key, string def)
    {
        string v;
        if (_m.TryGetValue(key, out v)) return v;
        return def;
    }

    public int GetInt(string key, int def)
    {
        string v;
        if (_m.TryGetValue(key, out v))
        {
            int i;
            if (int.TryParse(v, NumberStyles.Integer, CultureInfo.InvariantCulture, out i)) return i;
        }
        return def;
    }

    public bool GetBool(string key, bool def)
    {
        string v;
        if (_m.TryGetValue(key, out v))
        {
            if (string.Equals(v, "true", StringComparison.OrdinalIgnoreCase)) return true;
            if (string.Equals(v, "false", StringComparison.OrdinalIgnoreCase)) return false;
        }
        return def;
    }

    public void Set(string key, string val) { _m[key] = val; }

    public void Save(string path)
    {
        List<string> entries = new List<string>();
        foreach (KeyValuePair<string, string> kv in _m)
        {
            bool num = false;
            bool b = false;
            string t = kv.Value;
            if (t == "true" || t == "false") b = true;
            else { int dummy; if (int.TryParse(t, NumberStyles.Integer, CultureInfo.InvariantCulture, out dummy)) num = true; }
            string v = num || b ? t : ("\"" + Escape(t) + "\"");
            entries.Add("  \"" + kv.Key + "\": " + v);
        }
        string body = string.Join(",\n", entries.ToArray());
        File.WriteAllText(path, "{\n" + body + "\n}\n", new UTF8Encoding(false));
    }
}

// ---------------------------------------------------------------------------
// Application configuration (defaults match this machine)
// ---------------------------------------------------------------------------
public class AppConfig
{
    public string ExeDir;
    public string ConfigPath;
    public string DataDir;       // restore points
    public string LogsDir;
    public string DshHome;
    public string Profile;
    public string ProfileDir;
    public string NodeExe;
    public string DshCli;
    public int Port;
    public bool AutoOpenUI;
    public string UiMode;        // edgeApp | default
    public int KeepRestorePoints;
    public int SuspectWindowSec;
    public int StableSec;
    public int RestoreCooldownSec;
    public int RestartLimit;
    public int HealthIntervalMs;
    public bool MonitorAutoRollback;
    public bool GuardMode;

    public static AppConfig Load(string exeDir, bool guardMode)
    {
        AppConfig c = new AppConfig();
        c.ExeDir = FlatConfig.NormalizeDir(exeDir);
        c.ConfigPath = c.ExeDir + "config.json";
        c.GuardMode = guardMode;

        FlatConfig cfg = FlatConfig.Load(c.ConfigPath);
        bool created = false;
        if (!File.Exists(c.ConfigPath))
        {
            created = true;
            c.DataDir = c.ExeDir + "data";
            c.LogsDir = c.ExeDir + "logs";
            c.DshHome = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\.dsh";
            c.Profile = "web";
            c.NodeExe = ProbeNodeExe();
            c.DshCli = c.ExeDir + "dsh-cli\\lib\\bin.js";
            c.Port = 3080;
            c.AutoOpenUI = true;
            c.UiMode = "edgeApp";
            c.KeepRestorePoints = 5;
            c.SuspectWindowSec = 150;
            c.StableSec = 45;
            c.RestoreCooldownSec = 240;
            c.RestartLimit = 2;
            c.HealthIntervalMs = 3000;
            c.MonitorAutoRollback = false;
            c.ProfileDir = c.DshHome + "\\profiles\\" + c.Profile;
            WriteDefaults(c);
        }
        else
        {
            c.DataDir = FlatConfig.NormalizeDir(cfg.GetStr("dataDir", c.ExeDir + "data"));
            c.LogsDir = FlatConfig.NormalizeDir(cfg.GetStr("logsDir", c.ExeDir + "logs"));
            c.DshHome = FlatConfig.NormalizeDir(cfg.GetStr("dshHome", Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\.dsh"));
            c.Profile = cfg.GetStr("profile", "web");
            string overrideProfileDir = cfg.GetStr("profileDir", "");
            c.NodeExe = cfg.GetStr("nodeExe", ProbeNodeExe());
            string cli = cfg.GetStr("dshCli", "");
            if (cli.Length == 0)
            {
                // search common npm global locations for the dsh CLI package
                string npmRoot = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\npm\\node_modules\\@deepseek-ai\\dsh\\lib\\bin.js";
                cli = File.Exists(npmRoot) ? npmRoot : (c.ExeDir + "dsh-cli\\lib\\bin.js");
            }
            c.DshCli = cli;
            c.Port = cfg.GetInt("port", 3080);
            c.AutoOpenUI = cfg.GetBool("autoOpenUI", true);
            c.UiMode = cfg.GetStr("uiMode", "edgeApp");
            c.KeepRestorePoints = cfg.GetInt("keepRestorePoints", 5);
            c.SuspectWindowSec = cfg.GetInt("suspectWindowSec", 150);
            c.StableSec = cfg.GetInt("stableSec", 45);
            c.RestoreCooldownSec = cfg.GetInt("restoreCooldownSec", 240);
            c.RestartLimit = cfg.GetInt("restartLimit", 2);
            c.HealthIntervalMs = cfg.GetInt("healthIntervalMs", 3000);
            c.MonitorAutoRollback = cfg.GetBool("monitorAutoRollback", false);
            c.ProfileDir = overrideProfileDir.Length > 0
                ? FlatConfig.NormalizeDir(overrideProfileDir)
                : (c.DshHome + "profiles\\" + c.Profile);
        }
        if (created) File.AppendAllText(c.ExeDir + "logs-start.txt", "default config written: " + c.ConfigPath + Environment.NewLine);
        return c;
    }

    private static string ProbeNodeExe()
    {
        string[] cands = {
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + "\\nodejs\\node.exe",
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + "\\nodejs\\node.exe",
            "node.exe"
        };
        foreach (string p in cands) if (File.Exists(p) || p == "node.exe") return p;
        return "node.exe";
    }

    private static void WriteDefaults(AppConfig c)
    {
        FlatConfig f = new FlatConfig();
        f.Set("dshHome", c.DshHome);
        f.Set("profile", c.Profile);
        f.Set("profileDir", c.ProfileDir);
        f.Set("nodeExe", c.NodeExe);
        f.Set("dshCli", c.DshCli);
        f.Set("dataDir", c.DataDir);
        f.Set("logsDir", c.LogsDir);
        f.Set("port", c.Port.ToString(CultureInfo.InvariantCulture));
        f.Set("autoOpenUI", c.AutoOpenUI ? "true" : "false");
        f.Set("uiMode", c.UiMode);
        f.Set("keepRestorePoints", c.KeepRestorePoints.ToString(CultureInfo.InvariantCulture));
        f.Set("suspectWindowSec", c.SuspectWindowSec.ToString(CultureInfo.InvariantCulture));
        f.Set("stableSec", c.StableSec.ToString(CultureInfo.InvariantCulture));
        f.Set("restoreCooldownSec", c.RestoreCooldownSec.ToString(CultureInfo.InvariantCulture));
        f.Set("restartLimit", c.RestartLimit.ToString(CultureInfo.InvariantCulture));
        f.Set("healthIntervalMs", c.HealthIntervalMs.ToString(CultureInfo.InvariantCulture));
        f.Set("monitorAutoRollback", c.MonitorAutoRollback ? "true" : "false");
        f.Save(c.ConfigPath);
    }
}

// ---------------------------------------------------------------------------
// Log sinks (runtime raw log, event log, plugin-activity log), rotated per run
// ---------------------------------------------------------------------------
public class LogSink
{
    private readonly object _lock = new object();
    private StreamWriter _raw;
    private StreamWriter _evt;
    private StreamWriter _plg;

    public string RuntimeFile { get; private set; }
    public string EventFile { get; private set; }
    public string PluginFile { get; private set; }

    public void Open(string logsDir)
    {
        try { Directory.CreateDirectory(logsDir); }
        catch { }
        string stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
        RuntimeFile = logsDir + "runtime-" + stamp + ".log";
        EventFile = logsDir + "events-" + stamp + ".log";
        PluginFile = logsDir + "plugin-" + stamp + ".log";
        lock (_lock)
        {
            _raw = new StreamWriter(RuntimeFile, true, new UTF8Encoding(false)) { AutoFlush = true };
            _evt = new StreamWriter(EventFile, true, new UTF8Encoding(false)) { AutoFlush = true };
            _plg = new StreamWriter(PluginFile, true, new UTF8Encoding(false)) { AutoFlush = true };
        }
    }

    public void Raw(string line)
    {
        lock (_lock) { if (_raw != null) _raw.WriteLine(line); }
    }

    public void Evt(string msg)
    {
        string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "  " + msg;
        lock (_lock)
        {
            if (_evt != null) _evt.WriteLine(line);
            if (_plg != null) _plg.WriteLine(line);
        }
    }

    public void Plugin(string msg)
    {
        string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "  " + msg;
        lock (_lock) { if (_plg != null) _plg.WriteLine(line); }
    }

    public void Close()
    {
        lock (_lock)
        {
            if (_raw != null) { _raw.Flush(); _raw.Dispose(); _raw = null; }
            if (_evt != null) { _evt.Flush(); _evt.Dispose(); _evt = null; }
            if (_plg != null) { _plg.Flush(); _plg.Dispose(); _plg = null; }
        }
    }
}

// ---------------------------------------------------------------------------
// State signature: profile package.json / patches / home settings / top-level
// node_modules layout. Content hashes so boot-time regeneration of cordis.yml
// (same bytes) does not count as a plugin change.
// ---------------------------------------------------------------------------
public class StateSignature
{
    public static string HashFile(string path)
    {
        try
        {
            if (!File.Exists(path)) return "<absent>";
            byte[] data = File.ReadAllBytes(path);
            using (SHA1 sha = SHA1.Create())
            {
                byte[] h = sha.ComputeHash(data);
                StringBuilder sb = new StringBuilder(h.Length * 2);
                foreach (byte b in h) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }
        catch { return "<err>"; }
    }

    private static string TopDirs(string dir)
    {
        try
        {
            if (!Directory.Exists(dir)) return "<absent>";
            string[] dirs = Directory.GetDirectories(dir);
            Array.Sort(dirs, StringComparer.Ordinal);
            StringBuilder sb = new StringBuilder();
            foreach (string d in dirs) sb.Append(Path.GetFileName(d)).Append('/');
            return sb.ToString();
        }
        catch { return "<err>"; }
    }

    private static string TopFiles(string dir)
    {
        try
        {
            if (!Directory.Exists(dir)) return "<absent>";
            string[] files = Directory.GetFiles(dir);
            Array.Sort(files, StringComparer.Ordinal);
            StringBuilder sb = new StringBuilder();
            foreach (string f in files) sb.Append(Path.GetFileName(f)).Append('/');
            return sb.ToString();
        }
        catch { return "<err>"; }
    }

    public static string Compute(string profileDir, string dshHome, List<string> profileStateFiles, List<string> homeStateFiles)
    {
        StringBuilder sb = new StringBuilder();
        foreach (string f in profileStateFiles) sb.Append("PF:").Append(Path.GetFileName(f)).Append('=').Append(HashFile(profileDir + Path.GetFileName(f))).Append('\n');
        foreach (string f in homeStateFiles) sb.Append("HF:").Append(Path.GetFileName(f)).Append('=').Append(HashFile(dshHome + Path.GetFileName(f))).Append('\n');
        sb.Append("NM1:").Append(TopDirs(profileDir + "node_modules")).Append('\n');
        sb.Append("PDIRTOP:").Append(TopFiles(profileDir)).Append('\n');
        string profilesDir = Path.GetDirectoryName(profileDir.TrimEnd('\\'));
        if (profilesDir != null) sb.Append("NM2:").Append(TopDirs(FlatConfig.NormalizeDir(profilesDir) + "node_modules")).Append('\n');
        return sb.ToString();
    }
}

// ---------------------------------------------------------------------------
// Restore points (state-file snapshots) + rollback
// ---------------------------------------------------------------------------
public class RestorePointStore
{
    private readonly string _root;
    private readonly string _profileDir;
    private readonly string _dshHome;
    private readonly List<string> _profileStateFiles;
    private readonly List<string> _homeStateFiles;
    private readonly int _keep;

    public RestorePointStore(AppConfig c)
    {
        _root = FlatConfig.NormalizeDir(c.DataDir) + "restore-points";
        _profileDir = c.ProfileDir;
        _dshHome = c.DshHome;
        _profileStateFiles = ProfileStateFileNames();
        _homeStateFiles = HomeStateFileNames(c);
        _keep = c.KeepRestorePoints;
    }

    public static List<string> ProfileStateFileNames()
    {
        return new List<string> { "package.json", "cordis.patch.yml", "pnpm-workspace.yaml", "pnpm-lock.yaml", ".npmrc" };
    }

    public static List<string> HomeStateFileNames(AppConfig c)
    {
        List<string> names = new List<string> { "settings.yaml" };
        try
        {
            if (Directory.Exists(c.DshHome))
            {
                foreach (string f in Directory.GetFiles(c.DshHome, "*.patch.yml"))
                    names.Add(Path.GetFileName(f));
                foreach (string f in Directory.GetFiles(c.DshHome, "patch*.yaml"))
                    if (!names.Contains(Path.GetFileName(f))) names.Add(Path.GetFileName(f));
            }
        }
        catch { }
        return names;
    }

    private string PrefixFor(string file)
    {
        foreach (string n in _profileStateFiles)
            if (string.Equals(n, file, StringComparison.OrdinalIgnoreCase)) return "P__" + n;
        return "H__" + file;
    }

    private string DestFor(string fileName)
    {
        if (fileName.StartsWith("P__")) return _profileDir + fileName.Substring(3);
        if (fileName.StartsWith("H__")) return _dshHome + fileName.Substring(3);
        return null;
    }

    public List<string> ListPoints()
    {
        List<string> list = new List<string>();
        try
        {
            if (Directory.Exists(_root))
                list.AddRange(Directory.GetDirectories(_root));
        }
        catch { }
        list.Sort(StringComparer.Ordinal);
        return list;
    }

    public string Create(string reason, string note)
    {
        try { Directory.CreateDirectory(_root); }
        catch { }
        string name = "RP-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
        string dir = _root + "\\" + name;
        Directory.CreateDirectory(dir);
        File.WriteAllText(dir + "\\meta.txt",
            "created=" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + Environment.NewLine +
            "reason=" + reason + Environment.NewLine +
            "note=" + note + Environment.NewLine, new UTF8Encoding(false));
        StringBuilder list = new StringBuilder();
        List<string> copied = new List<string>();
        foreach (string n in _profileStateFiles)
        {
            string src = _profileDir + n;
            if (!File.Exists(src)) continue;
            File.Copy(src, dir + "\\" + PrefixFor(n), true);
            list.AppendLine(PrefixFor(n));
            copied.Add(n);
        }
        foreach (string n in _homeStateFiles)
        {
            string src = _dshHome + n;
            if (!File.Exists(src)) continue;
            File.Copy(src, dir + "\\" + PrefixFor(n), true);
            list.AppendLine(PrefixFor(n));
            copied.Add(n);
        }
        File.WriteAllText(dir + "\\files.txt", list.ToString(), new UTF8Encoding(false));
        Rotate();
        return dir;
    }

    public string LatestBefore(DateTime beforeUtc)
    {
        List<string> pts = ListPoints();
        for (int i = pts.Count - 1; i >= 0; i--)
        {
            string name = Path.GetFileName(pts[i]);
            DateTime t;
            if (DateTime.TryParseExact(name, "RP-yyyyMMdd-HHmmss", CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out t))
            {
                if (t.ToUniversalTime() < beforeUtc) return pts[i];
            }
        }
        return null;
    }

    public string Latest()
    {
        List<string> pts = ListPoints();
        return pts.Count > 0 ? pts[pts.Count - 1] : null;
    }

    public List<string> Rollback(string pointDir)
    {
        List<string> restored = new List<string>();
        if (pointDir == null || !Directory.Exists(pointDir)) return restored;
        string filesTxt = pointDir + "\\files.txt";
        if (!File.Exists(filesTxt)) return restored;
        foreach (string line in File.ReadAllLines(filesTxt))
        {
            string f = line.Trim();
            if (f.Length == 0) continue;
            string src = pointDir + "\\" + f;
            string dst = DestFor(f);
            if (dst == null || !File.Exists(src)) continue;
            try
            {
                string tmp = dst + ".rp-tmp";
                File.Copy(src, tmp, true);
                File.Copy(tmp, dst, true);
                File.Delete(tmp);
                restored.Add(Path.GetFileName(dst));
            }
            catch (Exception ex)
            {
                restored.Add(Path.GetFileName(dst) + " (FAILED: " + ex.Message + ")");
            }
        }
        return restored;
    }

    private void Rotate()
    {
        try
        {
            List<string> pts = ListPoints();
            while (pts.Count > _keep)
            {
                Directory.Delete(pts[0], true);
                pts.RemoveAt(0);
            }
        }
        catch { }
    }
}

// ---------------------------------------------------------------------------
// Guardian: server child, health probe, plugin-change watchdog, rollback
// ---------------------------------------------------------------------------
public enum WatchState { Idle, Starting, Running, Suspect, RollingBack, Stopped, MonitorOnly, Failed }

public class Guardian
{
    public AppConfig Cfg;
    public LogSink Sink;
    public RestorePointStore Store;

    public event Action<string> RawLine;
    public event Action<string> EvtLine;
    public event Action<string> UrlFound;
    public event Action<WatchState, string> StateChanged;
    public event Action<string> Important;   // balloon-worthy

    private readonly object _lock = new object();
    private Process _child;
    private volatile bool _wantStop;        // user asked to stop
    private volatile bool _run;             // supervision thread run flag
    private Thread _pollThread;
    private string _currentUrl;
    private string _lastSig;
    private DateTime? _suspectSince;
    private DateTime _lastChangeUtc;
    private DateTime? _pendingRpUtc;
    private DateTime _lastRpUtc = DateTime.MinValue;
    private int _restartCount;
    private bool _rollbackUsed;
    private bool _bootRollbackTried;
    private int _missed;
    private bool _externalDownLogged;
    private bool _extRunningLogged;
    private bool _serverEverHealthy;
    private WatchState _state = WatchState.Stopped;
    private readonly List<string> _stateFiles;   // watch files (profile)
    private readonly List<string> _homeFiles;

    public bool OwnChild { get { lock (_lock) { return _child != null; } } }
    public bool IsSupervising { get { return _run; } }
    public WatchState State { get { lock (_lock) { return _state; } } }
    public string CurrentUrl { get { return _currentUrl; } }

    public Guardian(AppConfig cfg)
    {
        Cfg = cfg;
        Sink = new LogSink();
        Store = new RestorePointStore(cfg);
        _stateFiles = new List<string> { "package.json", "cordis.patch.yml", "pnpm-workspace.yaml", "pnpm-lock.yaml", ".npmrc" };
        _homeFiles = new List<string>();
        foreach (string n in RestorePointStore.HomeStateFileNames(cfg))
            _homeFiles.Add(n);
        Sink.Open(cfg.LogsDir);
        Sink.Evt("========== DSH 桌面版 / AI 哨兵 启动 ==========");
        Sink.Evt("配置: profile=" + cfg.Profile + " profileDir=" + cfg.ProfileDir);
        Sink.Evt("配置: nodeExe=" + cfg.NodeExe + " dshCli=" + cfg.DshCli);
    }

    private void SetState(WatchState st, string detail)
    {
        WatchState old;
        lock (_lock)
        {
            old = _state;
            _state = st;
        }
        if (old != st)
        {
            Sink.Evt("状态: " + st + (detail.Length > 0 ? " — " + detail : ""));
            if (StateChanged != null) StateChanged(st, detail);
        }
    }

    public void StartSupervision(bool startServerIfFree)
    {
        if (_run) return;
        _run = true;
        _wantStop = false;
        _pollThread = new Thread(PollLoop);
        _pollThread.IsBackground = true;
        _pollThread.Start();

        if (startServerIfFree) StartServer();
        else
        {
            SetState(WatchState.MonitorOnly, "仅监控模式：不启动/停止外部实例");
            Sink.Evt("仅监控外部实例（端口 " + Cfg.Port + "）…");
        }
    }

    public void StopSupervision()
    {
        _run = false;
        StopServerInternal(true);
        Sink.Close();
    }

    // ---- server lifecycle -------------------------------------------------

    public void StartServer()
    {
        lock (_lock)
        {
            if (_child != null && !_child.HasExited)
            {
                Sink.Evt("服务已在运行，忽略重复启动请求");
                return;
            }
            _wantStop = false;
            _child = null;
        }
        if (!File.Exists(Cfg.NodeExe) && Cfg.NodeExe != "node.exe")
        {
            EmitError("找不到 node.exe: " + Cfg.NodeExe + "（请在 config.json 中修正 nodeExe）");
            return;
        }
        if (!File.Exists(Cfg.DshCli))
        {
            EmitError("找不到 dsh CLI: " + Cfg.DshCli + "（请在 config.json 中修正 dshCli）");
            return;
        }
        if (!Directory.Exists(Cfg.ProfileDir))
        {
            EmitError("profile 目录不存在: " + Cfg.ProfileDir + "（dsh 会自动初始化，但需要 DSH_HOME 可写）");
        }
        try { Directory.CreateDirectory(Cfg.ProfileDir); }
        catch (Exception ex) { EmitError("无法创建 profile 目录: " + ex.Message); return; }

        SetState(WatchState.Starting, "启动 dsh web（端口 " + Cfg.Port + "）…");
        Sink.Evt("启动服务: " + Cfg.NodeExe + " " + Cfg.DshCli + " --profile " + Cfg.Profile + " --port " + Cfg.Port + " --no-open");

        try
        {
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = Cfg.NodeExe;
            psi.Arguments = "\"" + Cfg.DshCli + "\" --profile " + Cfg.Profile +
                            " --port " + Cfg.Port.ToString(CultureInfo.InvariantCulture) + " --no-open";
            psi.WorkingDirectory = Cfg.ProfileDir;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = new UTF8Encoding(false);
            psi.StandardErrorEncoding = new UTF8Encoding(false);
            psi.EnvironmentVariables["DSH_HOME"] = Cfg.DshHome.TrimEnd('\\');

            Process p = new Process();
            p.StartInfo = psi;
            p.EnableRaisingEvents = true;
            p.OutputDataReceived += OnChildOut;
            p.ErrorDataReceived += OnChildErr;
            p.Exited += delegate
            {
                Sink.Evt("子进程已退出（exit=" + p.ExitCode + "）");
            };
            lock (_lock)
            {
                _child = p;
                _serverEverHealthy = false;
                _missed = 0;
                _bootRollbackTried = false;
            }
            p.Start();
            p.BeginOutputReadLine();
            p.BeginErrorReadLine();
            Sink.Evt("服务进程已启动 (PID " + p.Id + ")");
        }
        catch (Exception ex)
        {
            EmitError("启动服务失败 [" + ex.GetType().Name + "]: " + ex.Message);
            Sink.Evt("启动服务失败详情: " + ex);
            lock (_lock)
            {
                if (_child != null)
                {
                    try { _child = null; }
                    catch { }
                }
            }
            SetState(WatchState.Failed, ex.Message);
        }
    }

    private void OnChildOut(object sender, DataReceivedEventArgs e)
    {
        if (e.Data != null) HandleChildLine(e.Data, false);
    }

    private void OnChildErr(object sender, DataReceivedEventArgs e)
    {
        if (e.Data != null) HandleChildLine(e.Data, true);
    }

    private void HandleChildLine(string data, bool isErr)
    {
        string line = Ansi.Strip(data);
        if (line.Length == 0) return;
        Sink.Raw((isErr ? "[err] " : "") + line);
        if (RawLine != null) RawLine(line);
        string url = Ansi.FindDshUrl(line);
        if (url != null && _currentUrl != url)
        {
            _currentUrl = url;
            Sink.Evt("捕获界面地址: " + url);
            if (UrlFound != null) UrlFound(url);
        }
        // coarse error marker for the plugin/activity log
        if (isErr || line.IndexOf("error", StringComparison.OrdinalIgnoreCase) >= 0 ||
            line.IndexOf("failed", StringComparison.OrdinalIgnoreCase) >= 0 ||
            line.IndexOf("exception", StringComparison.OrdinalIgnoreCase) >= 0)
        {
            Sink.Plugin("[日志] " + line);
        }
    }

    public void StopServer()
    {
        StopServerInternal(false);
    }

    private void StopServerInternal(bool supervisionTeardown)
    {
        Process victim = null;
        lock (_lock)
        {
            _wantStop = true;
            if (_child != null)
            {
                victim = _child;
                _child = null;
            }
        }
        if (victim != null && !victim.HasExited)
        {
            Sink.Evt("停止服务 (PID " + victim.Id + ")…");
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("taskkill.exe", "/PID " + victim.Id + " /T /F");
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                using (Process k = Process.Start(psi))
                {
                    if (k != null) k.WaitForExit(8000);
                }
            }
            catch (Exception ex)
            {
                Sink.Evt("停止服务出错（尝试直接终止）: " + ex.Message);
                try { if (!victim.HasExited) victim.Kill(); }
                catch { }
            }
            try { victim.WaitForExit(3000); }
            catch { }
        }
        if (!supervisionTeardown)
        {
            SetState(WatchState.Stopped, "服务已停止（保留监视中，可随时启动）");
            Sink.Evt("服务已停止");
        }
    }

    private void EmitError(string msg)
    {
        Sink.Evt("[错误] " + msg);
        if (EvtLine != null) EvtLine("[错误] " + msg);
        if (Important != null) Important("[错误] " + msg);
    }

    // ---- health -----------------------------------------------------------

    private enum AliveKind { Down, Dsh, Other }

    private AliveKind Probe()
    {
        try
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:" + Cfg.Port + "/");
            req.Method = "GET";
            req.Timeout = 1800;
            req.AllowAutoRedirect = false;
            try
            {
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                    {
                        string body = sr.ReadToEnd();
                        if (body.IndexOf("dsh web authentication required", StringComparison.OrdinalIgnoreCase) >= 0) return AliveKind.Dsh;
                    }
                    return AliveKind.Other;
                }
            }
            catch (WebException wex)
            {
                HttpWebResponse resp = wex.Response as HttpWebResponse;
                if (resp != null)
                {
                    if (resp.StatusCode == HttpStatusCode.Unauthorized) return AliveKind.Dsh;
                    return AliveKind.Other;
                }
                return AliveKind.Down;
            }
        }
        catch { return AliveKind.Down; }
    }

    // ---- signature / watchdog --------------------------------------------

    private string ComputeSig()
    {
        return StateSignature.Compute(Cfg.ProfileDir, Cfg.DshHome, _stateFiles, _homeFiles);
    }

    private void PollLoop()
    {
        int interval = Cfg.HealthIntervalMs;
        DateTime lastProbeUtc = DateTime.MinValue;
        while (_run)
        {
            try
            {
                DateTime nowUtc = DateTime.UtcNow;
                bool own;
                lock (_lock) own = _child != null;

                if (own)
                {
                    Process p = null;
                    lock (_lock) p = _child;
                    if (p != null && p.HasExited)
                    {
                        int code = -1;
                        try { code = p.ExitCode; }
                        catch { }
                        lock (_lock) _child = null;
                        if (_wantStop) { Sink.Evt("服务已按要求停止，不再自动重启"); }
                        else HandleFailure("进程退出(exit=" + code + ")");
                    }
                    else if ((nowUtc - lastProbeUtc).TotalMilliseconds >= interval)
                    {
                        lastProbeUtc = nowUtc;
                        AliveKind ak = Probe();
                        if (ak == AliveKind.Down)
                        {
                            _missed++;
                            if (_missed >= 2) HandleFailure("健康检查失败（端口无响应）");
                        }
                        else
                        {
                            bool wasDown = _missed >= 2;
                            _missed = 0;
                            if (!_serverEverHealthy)
                            {
                                _serverEverHealthy = true;
                                _restartCount = 0;
                                _bootRollbackTried = false;
                                Sink.Evt("服务健康：HTTP " + (ak == AliveKind.Dsh ? "dsh web" : "响应") + " @" + Cfg.Port);
                                SetState(WatchState.Running, "运行中 · 端口 " + Cfg.Port);
                                // first restore point shortly after a healthy boot
                                if (DateTime.UtcNow - _lastRpUtc > TimeSpan.FromSeconds(10))
                                {
                                    if (Store.ListPoints().Count == 0 || DateTime.UtcNow - _lastRpUtc > TimeSpan.FromSeconds(Cfg.RestoreCooldownSec))
                                        TryAutoRestorePoint("启动后首个恢复点");
                                }
                            }
                            if (wasDown)
                            {
                                Sink.Evt("服务已恢复健康");
                                SetState(WatchState.Running, "运行中（已恢复）");
                            }
                            WatchHealthyTick(nowUtc, true);
                        }
                    }
                }
                else
                {
                    // monitor-only path (external instance or stopped)
                    if ((nowUtc - lastProbeUtc).TotalMilliseconds >= interval)
                    {
                        lastProbeUtc = nowUtc;
                        AliveKind ak = Probe();
                        if (ak == AliveKind.Down)
                        {
                            _missed++;
                            if (_missed >= 2 && !_externalDownLogged && _state == WatchState.MonitorOnly)
                            {
                                _externalDownLogged = true;
                                Sink.Evt("外部实例失去响应（端口 " + Cfg.Port + " 无应答）");
                                if (Important != null) Important("外部实例失去响应（端口 " + Cfg.Port + "）");
                                if (_suspectSince.HasValue)
                                {
                                    if (Cfg.MonitorAutoRollback)
                                    {
                                        Sink.Plugin("!!! 外部实例在插件变更观察窗口内崩溃 —— 自动回滚状态文件（实例需手动重启）");
                                        DoRollback(_suspectSince.Value, "自动回滚（外部实例崩溃于观察窗口）");
                                        _suspectSince = null;
                                        if (Important != null) Important("已自动回滚外部实例的状态文件，请手动重启该实例");
                                    }
                                    else
                                    {
                                        Sink.Plugin("外部实例在插件变更观察窗口内崩溃（monitorAutoRollback=false，未自动回滚）。可手动“回滚最近点”后重启外部实例。");
                                    }
                                }
                            }
                        }
                        else
                        {
                            bool wasDown = _missed >= 2;
                            _missed = 0;
                            _externalDownLogged = false;
                            if (!_extRunningLogged)
                            {
                                _extRunningLogged = true;
                                Sink.Evt("端口 " + Cfg.Port + " 检测到 " +
                                         (ak == AliveKind.Dsh ? "dsh web 实例" : "HTTP 服务") +
                                         " 运行中（本程序未管理该进程，仅监控）");
                                SetState(WatchState.MonitorOnly, "外部实例运行中 @ " + Cfg.Port);
                            }
                            if (wasDown)
                            {
                                Sink.Evt("外部实例已恢复应答");
                                SetState(WatchState.MonitorOnly, "外部实例运行中（已恢复）@ " + Cfg.Port);
                            }
                            WatchHealthyTick(nowUtc, false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                try { Sink.Evt("监视循环异常: " + ex.Message); }
                catch { }
            }
            Thread.Sleep(600);
        }
    }

    private void WatchHealthyTick(DateTime nowUtc, bool childOwned)
    {
        string sig = ComputeSig();
        if (_lastSig == null) _lastSig = sig;
        if (sig != _lastSig)
        {
            _lastSig = sig;
            if (!_suspectSince.HasValue)
            {
                _suspectSince = nowUtc;
                _lastChangeUtc = nowUtc;
                _rollbackUsed = false;
                SetState(WatchState.Suspect, "检测到插件/配置变更，观察稳定性中");
                Sink.Plugin(">>> 检测到 profile 变更（插件安装/卸载/配置修改？）——进入 " + Cfg.SuspectWindowSec + "s 观察窗口，此间发生崩溃将自动回滚到最近的“变更前”恢复点");
                if (Important != null) Important("检测到插件/配置变更，正在观察运行稳定性…");
            }
            else
            {
                _lastChangeUtc = nowUtc;
                Sink.Plugin(">>> 观察窗口内再次检测到变更…");
            }
        }

        if (_suspectSince.HasValue)
        {
            double since = (nowUtc - _suspectSince.Value).TotalSeconds;
            double quiet = (nowUtc - _lastChangeUtc).TotalSeconds;
            bool windowExpired = since >= Cfg.SuspectWindowSec;
            bool stableAndQuiet = quiet >= Cfg.StableSec && since >= 10;
            if (windowExpired || stableAndQuiet)
            {
                _suspectSince = null;
                Sink.Plugin("<<< 观察窗口结束：变更后运行稳定，未崩溃。" +
                            (windowExpired ? "（窗口超时）" : "（稳定 " + Math.Round(quiet) + "s）"));
                _restartCount = 0;
                _pendingRpUtc = nowUtc.AddSeconds(5);
                SetState(childOwned ? WatchState.Running : WatchState.MonitorOnly,
                         childOwned ? ("运行中 · 端口 " + Cfg.Port) : ("外部实例运行中 @ " + Cfg.Port));
                if (Important != null) Important("插件变更已稳定运行，监护正常");
            }
        }
        else if (_pendingRpUtc.HasValue && nowUtc >= _pendingRpUtc.Value)
        {
            _pendingRpUtc = null;
            TryAutoRestorePoint("变更稳定后的恢复点");
        }
        else if (_lastRpUtc != DateTime.MinValue &&
                 (nowUtc - _lastRpUtc).TotalSeconds >= Cfg.RestoreCooldownSec &&
                 !_pendingRpUtc.HasValue)
        {
            TryAutoRestorePoint("周期恢复点");
        }
    }

    private void TryAutoRestorePoint(string why)
    {
        try
        {
            _lastRpUtc = DateTime.UtcNow;
            string rp = Store.Create(why, "auto");
            Sink.Plugin("[恢复点] 已创建: " + Path.GetFileName(rp) + "  (" + why + ")");
            if (Important != null && _state != WatchState.Starting) { }
        }
        catch (Exception ex)
        {
            Sink.Evt("[恢复点] 创建失败: " + ex.Message);
        }
    }

    private void HandleFailure(string detail)
    {
        bool rollbackDone = false;
        if (_suspectSince.HasValue && !_rollbackUsed)
        {
            _rollbackUsed = true;
            Sink.Plugin("!!! 在插件变更观察窗口内发生故障: " + detail + " —— 执行自动回滚");
            rollbackDone = DoRollback(_suspectSince.Value, "自动回滚（插件变更后崩溃）");
            if (!rollbackDone)
            {
                Sink.Plugin("自动回滚不可用（无匹配恢复点），尝试直接重启…");
                if (Important != null) Important("插件变更后发生故障，但没有可用的恢复点，尝试直接重启");
            }
            _suspectSince = null;
            _restartCount = 0;
            StartServer();
            return;
        }

        // boot failed before the service ever became healthy -> a broken plugin /
        // profile state is the prime suspect: roll back to the latest known-good
        // restore point (once per start attempt) before doing plain restarts.
        if (!_serverEverHealthy && !_bootRollbackTried && Store.Latest() != null)
        {
            _bootRollbackTried = true;
            Sink.Plugin("服务在启动阶段失败（未能进入健康状态）——自动回滚到最近恢复点后重试: " + detail);
            rollbackDone = DoRollbackLatest("启动失败自动回滚");
            if (rollbackDone) { StartServer(); return; }
        }

        _restartCount++;
        if (_restartCount <= Cfg.RestartLimit)
        {
            Sink.Evt("服务故障: " + detail + " —— 自动重启 (" + _restartCount + "/" + Cfg.RestartLimit + ")");
            try { Thread.Sleep(1500); }
            catch { }
            StartServer();
        }
        else
        {
            SetState(WatchState.Failed, "连续失败，已停止自动重启");
            Sink.Evt("服务故障: " + detail + " —— 已超过重启上限，停止自动重启。建议手动“回滚”或检查日志。");
            if (Important != null) Important("服务连续故障已停止自动重启；可点“回滚到最近恢复点”恢复");
        }
    }

    public string SnapshotNow(string reason)
    {
        string rp = Store.Create(reason, "manual");
        _lastRpUtc = DateTime.UtcNow;
        Sink.Plugin("[恢复点] 手动/按需创建: " + Path.GetFileName(rp) + "  (" + reason + ")");
        return rp;
    }

    public bool DoRollback(DateTime beforeUtc, string why)
    {
        string point = Store.LatestBefore(beforeUtc);
        if (point == null)
        {
            Sink.Evt("回滚失败：在 " + beforeUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss") + " 之前没有可用的恢复点");
            return false;
        }
        return DoRollbackPoint(point, why);
    }

    public bool DoRollbackLatest(string why)
    {
        string point = Store.Latest();
        if (point == null)
        {
            Sink.Evt("回滚失败：没有可用的恢复点");
            return false;
        }
        return DoRollbackPoint(point, why);
    }

    private bool DoRollbackPoint(string point, string why)
    {
        Sink.Evt("回滚到恢复点 " + Path.GetFileName(point) + "（" + why + "）");
        bool hadChild;
        lock (_lock) hadChild = _child != null;
        if (hadChild) StopServerInternal(false);

        List<string> restored = Store.Rollback(point);
        Sink.Evt("回滚完成，恢复文件: " + string.Join(", ", restored.ToArray()));
        if (restored.Count == 0) Sink.Evt("注意：恢复点中没有发现需要恢复的文件");

        // what changed in package.json dependencies (best-effort plugin name)
        string diff = TryDiffDeps(point);
        if (diff.Length > 0) Sink.Plugin("回滚涉及: " + diff);

        SetState(WatchState.RollingBack, "已回滚 " + Path.GetFileName(point));
        if (Important != null) Important("已回滚到恢复点 " + Path.GetFileName(point) + (diff.Length > 0 ? "（涉及 " + diff + "）" : ""));
        return true;
    }

    private string TryDiffDeps(string point)
    {
        try
        {
            string cur = Cfg.ProfileDir + "package.json";
            string bak = point + "\\P__package.json";
            if (!File.Exists(cur) || !File.Exists(bak)) return "";
            Regex rx = new Regex("\"([^\"@][^\"]*)\"\\s*:\\s*\"[^\"]*\"", RegexOptions.Compiled);
            HashSet<string> a = new HashSet<string>();
            HashSet<string> b = new HashSet<string>();
            foreach (Match m in rx.Matches(File.ReadAllText(cur))) a.Add(m.Groups[1].Value);
            foreach (Match m in rx.Matches(File.ReadAllText(bak))) b.Add(m.Groups[1].Value);
            List<string> added = a.Where(x => !b.Contains(x)).ToList();
            List<string> removed = b.Where(x => !a.Contains(x)).ToList();
            added.Sort(StringComparer.Ordinal);
            removed.Sort(StringComparer.Ordinal);
            if (added.Count == 0 && removed.Count == 0) return "";
            return "新增=" + string.Join(",", added.ToArray()) + " ; 移除=" + string.Join(",", removed.ToArray());
        }
        catch { return ""; }
    }

    public void RestartService()
    {
        StopServerInternal(false);
        Thread.Sleep(400);
        StartServer();
    }

    public void DisposeLogs()
    {
        try { Sink.Close(); }
        catch { }
    }
}

// ---------------------------------------------------------------------------
// ANSI / URL helpers
// ---------------------------------------------------------------------------
public static class Ansi
{
    private static readonly Regex AnsiRx = new Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]", RegexOptions.Compiled);

    public static string Strip(string s)
    {
        if (s == null) return "";
        s = s.Replace("\r", "");
        return AnsiRx.Replace(s, "");
    }

    public static string FindDshUrl(string line)
    {
        // "dsh web: http://127.0.0.1:3080/?token=..."
        int idx = line.IndexOf("dsh web:", StringComparison.OrdinalIgnoreCase);
        string seg = idx >= 0 ? line.Substring(idx + 8) : line;
        Regex rx = new Regex("(https?://[^\\s()<>]+)", RegexOptions.Compiled);
        MatchCollection ms = rx.Matches(seg);
        string best = null;
        foreach (Match m in ms)
        {
            string u = m.Groups[1].Value.TrimEnd('.', ',', ';');
            if (best == null) best = u;
            if (u.IndexOf("token=", StringComparison.OrdinalIgnoreCase) >= 0 ||
                u.IndexOf("?auth", StringComparison.OrdinalIgnoreCase) >= 0) return u;
        }
        return best;
    }
}

// ---------------------------------------------------------------------------
// Main UI (windowed controller) + tray
// ---------------------------------------------------------------------------
public class HarnessApp : ApplicationContext
{
    private readonly AppConfig _cfg;
    private readonly bool _trayOnly;
    private readonly bool _directOpen;
    private Guardian _guard;
    private Form _form;
    private NotifyIcon _tray;
    private TextBox _logBox;
    private Label _statusLabel;
    private Label _urlLabel;
    private Button _btnStart, _btnStop, _btnOpen, _btnSnap, _btnRoll, _btnLogs;
    private readonly object _uiQ = new object();
    private List<string> _uiQueue = new List<string>();
    private readonly System.Windows.Forms.Timer _uiTimer;
    private bool _openedOnce;
    private DateTime _lastBalloon = DateTime.MinValue;
    private string _uiStateText = "";

    public HarnessApp(AppConfig cfg, bool trayOnly, bool directOpen)
    {
        _cfg = cfg;
        _trayOnly = trayOnly;
        _directOpen = directOpen;
        _guard = new Guardian(cfg);
        _guard.RawLine += OnRaw;
        _guard.EvtLine += OnEvt;
        _guard.UrlFound += OnUrl;
        _guard.StateChanged += OnState;
        _guard.Important += OnImportant;

        _uiTimer = new System.Windows.Forms.Timer();
        _uiTimer.Interval = 350;
        _uiTimer.Tick += delegate { DrainQueue(); };
        _uiTimer.Start();

        BuildTray();
        if (!_trayOnly)
        {
            BuildForm();
        }
        else
        {
            _form = null;
        }

        string who;
        bool serverShouldStart = ProbePort(out who);
        if (serverShouldStart)
        {
            _guard.StartSupervision(true);
        }
        else
        {
            // port busy: windowed mode asks what to do; tray modes stay silent
            if (_trayOnly)
            {
                _guard.StartSupervision(false);
                if (_directOpen)
                {
                    Notify("端口 " + _cfg.Port + " 已有 " + who + " 在运行 —— 尝试直接打开 Harness 网页（浏览器已记住授权则直接进入）", 4500);
                    OpenPlainAfterDelay();
                }
                else
                {
                    Notify("端口 " + _cfg.Port + " 已被占用（" + who + "）——AI 哨兵以“仅监控”模式运行", 5000);
                }
            }
            else
            {
                string msg = "端口 " + _cfg.Port + " 已被占用（" + who + "）。\n\n" +
                             "选择如何处理：\n\n" +
                             "[是]   关闭该占用进程后由本程序启动并接管服务\n" +
                             "       （会终止该实例及其界面会话，请先确认没有重要工作）\n\n" +
                             "[否]   以“仅监控”模式运行（不启动/停止外部实例，只记录事件、创建恢复点，可手动回滚）\n\n" +
                             "[取消] 退出本程序";
                DialogResult dr = MessageBox.Show(msg, "DSH 桌面版 — 端口占用", MessageBoxButtons.YesNoCancel,
                    MessageBoxIcon.Question, MessageBoxDefaultButton.Button3);
                if (dr == DialogResult.Yes)
                {
                    SinkEvt("用户选择接管：尝试停止占用进程…");
                    bool killed = KillPortOwner();
                    Thread.Sleep(500);
                    if (!ProbePort(out who)) _guard.StartSupervision(true);
                    else { MessageBox.Show("仍无法释放端口 " + _cfg.Port + "，已改为仅监控模式。", "DSH 桌面版"); _guard.StartSupervision(false); }
                }
                else if (dr == DialogResult.No)
                {
                    _guard.StartSupervision(false);
                }
                else
                {
                    ShutdownAll();
                    return;
                }
            }
        }

        if (_trayOnly)
        {
            // tray-only (guard / direct mode): no main window on startup
        }
        else
        {
            _form.Show();
        }
        _uiTimer.Start();
        Application.ThreadExit += delegate { Cleanup(); };
    }

    private void OpenPlainAfterDelay()
    {
        ThreadPool.QueueUserWorkItem(delegate
        {
            try { Thread.Sleep(900); }
            catch { }
            DefaultBrowserOpen("http://127.0.0.1:" + _cfg.Port + "/");
        });
    }

    private bool ProbePort(out string who)
    {
        who = "无";
        try
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:" + _cfg.Port + "/");
            req.Method = "GET";
            req.Timeout = 1200;
            req.AllowAutoRedirect = false;
            try
            {
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                    {
                        string body = sr.ReadToEnd();
                        who = body.IndexOf("dsh web authentication", StringComparison.OrdinalIgnoreCase) >= 0
                            ? "dsh web 实例" : "其它 HTTP 服务";
                    }
                    return false;
                }
            }
            catch (WebException wex)
            {
                HttpWebResponse resp = wex.Response as HttpWebResponse;
                if (resp != null)
                {
                    who = resp.StatusCode == HttpStatusCode.Unauthorized ? "dsh web 实例" : "其它 HTTP 服务";
                    return false;
                }
                return true;
            }
        }
        catch { return true; }
    }

    private bool KillPortOwner()
    {
        try
        {
            ProcessStartInfo psi = new ProcessStartInfo("netstat.exe", "-ano");
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            using (Process p = Process.Start(psi))
            {
                string outp = p.StandardOutput.ReadToEnd();
                p.WaitForExit(3000);
                string listen = "127.0.0.1:" + _cfg.Port;
                foreach (string line in outp.Split('\n'))
                {
                    if (line.IndexOf(listen, StringComparison.Ordinal) >= 0 &&
                        line.IndexOf("LISTENING", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        string[] parts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length >= 5)
                        {
                            int pid;
                            if (int.TryParse(parts[parts.Length - 1], out pid) && pid > 0)
                            {
                                if (pid == Process.GetCurrentProcess().Id) continue;
                                ProcessStartInfo tk = new ProcessStartInfo("taskkill.exe", "/PID " + pid + " /T /F");
                                tk.UseShellExecute = false;
                                tk.CreateNoWindow = true;
                                using (Process k = Process.Start(tk)) { if (k != null) k.WaitForExit(5000); }
                                SinkEvt("已尝试终止占用进程 PID " + pid);
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }
        catch (Exception ex)
        {
            SinkEvt("终止占用进程失败: " + ex.Message);
            return false;
        }
    }

    // ---- UI construction --------------------------------------------------

    private void BuildTray()
    {
        _tray = new NotifyIcon();
        _tray.Icon = SystemIcons.Application;
        _tray.Text = AppTitle();
        _tray.Visible = true;
        _tray.DoubleClick += delegate { ShowMain(); };

        ContextMenuStrip menu = new ContextMenuStrip();
        menu.Items.Add("显示/隐藏控制台", null, delegate { ShowMain(); });
        menu.Items.Add("打开 Harness 界面", null, delegate { OpenUi(); });
        menu.Items.Add("立即创建恢复点", null, delegate
        {
            string rp = _guard.SnapshotNow("托盘手动快照");
            Notify("恢复点已创建: " + Path.GetFileName(rp), 3000);
        });
        menu.Items.Add("回滚到最近恢复点", null, delegate
        {
            if (MessageBox.Show("回滚会把 profile 配置恢复为最近一次恢复点的内容，并重启服务。确定？",
                "回滚确认", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _guard.DoRollbackLatest("手动回滚（托盘）");
                _guard.StartServer();
            }
        });
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("启动服务", null, delegate { _guard.StartServer(); });
        menu.Items.Add("停止服务", null, delegate { _guard.StopServer(); });
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("打开日志目录", null, delegate { OpenFolder(_cfg.LogsDir); });
        menu.Items.Add("退出", null, delegate
        {
            if (MessageBox.Show("退出将停止本程序管理的 DeepSeek Harness 服务。确定退出？",
                "退出确认", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                ShutdownAll();
        });
        _tray.ContextMenuStrip = menu;
    }

    private void BuildForm()
    {
        _form = new Form();
        _form.Text = "DSH 桌面版 · 守护控制台（DeepSeek Harness）";
        _form.Width = 900;
        _form.Height = 620;
        _form.MinimumSize = new Size(640, 420);
        _form.StartPosition = FormStartPosition.CenterScreen;
        _form.FormClosing += delegate(object s, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                _form.Hide();
                Notify("已最小化到托盘，监护仍在运行", 1500);
            }
        };

        TableLayoutPanel top = new TableLayoutPanel();
        top.Dock = DockStyle.Top;
        top.Height = 64;
        top.ColumnCount = 1;
        top.Padding = new Padding(8, 6, 8, 2);
        top.RowCount = 2;

        _statusLabel = new Label();
        _statusLabel.Text = "正在初始化…";
        _statusLabel.Font = new Font("Microsoft YaHei UI", 10f, FontStyle.Bold);
        _statusLabel.ForeColor = Color.DimGray;
        _statusLabel.AutoSize = false;
        _statusLabel.Dock = DockStyle.Fill;
        _statusLabel.TextAlign = ContentAlignment.MiddleLeft;

        _urlLabel = new Label();
        _urlLabel.Text = "界面地址：尚未启动";
        _urlLabel.Font = new Font("Consolas", 9f);
        _urlLabel.ForeColor = Color.SteelBlue;
        _urlLabel.AutoSize = false;
        _urlLabel.Dock = DockStyle.Fill;
        _urlLabel.TextAlign = ContentAlignment.MiddleLeft;
        _urlLabel.Cursor = Cursors.Hand;
        _urlLabel.Click += delegate { OpenUi(); };

        top.Controls.Add(_statusLabel, 0, 0);
        top.Controls.Add(_urlLabel, 0, 1);
        _form.Controls.Add(top);

        TableLayoutPanel bottom = new TableLayoutPanel();
        bottom.Dock = DockStyle.Bottom;
        bottom.Height = 52;
        bottom.Padding = new Padding(8, 4, 8, 6);
        bottom.ColumnCount = 6;
        bottom.RowCount = 1;

        _btnStart = MakeButton("启动服务", delegate { _guard.StartServer(); });
        _btnStop = MakeButton("停止服务", delegate { _guard.StopServer(); });
        _btnOpen = MakeButton("打开界面", delegate { OpenUi(); });
        _btnSnap = MakeButton("现在快照", delegate { string rp = _guard.SnapshotNow("界面手动快照"); Notify("恢复点: " + Path.GetFileName(rp), 2000); });
        _btnRoll = MakeButton("回滚最近点", delegate
        {
            if (MessageBox.Show("回滚会把配置恢复到最近恢复点并重启服务。确定？", "回滚确认",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                _guard.DoRollbackLatest("手动回滚（界面）");
                _guard.StartServer();
            }
        });
        _btnLogs = MakeButton("打开日志", delegate { OpenFolder(_cfg.LogsDir); });

        bottom.Controls.Add(_btnStart, 0, 0);
        bottom.Controls.Add(_btnStop, 1, 0);
        bottom.Controls.Add(_btnOpen, 2, 0);
        bottom.Controls.Add(_btnSnap, 3, 0);
        bottom.Controls.Add(_btnRoll, 4, 0);
        bottom.Controls.Add(_btnLogs, 5, 0);
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.7f));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.7f));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.7f));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.7f));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.7f));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.7f));
        _form.Controls.Add(bottom);

        _logBox = new TextBox();
        _logBox.Dock = DockStyle.Fill;
        _logBox.Multiline = true;
        _logBox.ReadOnly = true;
        _logBox.ScrollBars = ScrollBars.Both;
        _logBox.BackColor = Color.FromArgb(15, 17, 21);
        _logBox.ForeColor = Color.LightGreen;
        _logBox.Font = new Font("Consolas", 9f);
        _logBox.WordWrap = false;
        _form.Controls.Add(_logBox);
        _logBox.BringToFront();

        // margins so log does not hide under top/bottom panels
        _logBox.Padding = new Padding(4);

        _form.Resize += delegate
        {
            // keep layout: textbox fill works with docking order; nothing needed
        };
    }

    private Button MakeButton(string text, EventHandler onClick)
    {
        Button b = new Button();
        b.Text = text;
        b.Dock = DockStyle.Fill;
        b.Margin = new Padding(2, 0, 2, 0);
        b.UseVisualStyleBackColor = true;
        b.Click += onClick;
        return b;
    }

    private void ShowMain()
    {
        if (_form == null)
        {
            BuildForm();
        }
        if (!_form.Visible)
        {
            _form.Show();
            _form.WindowState = FormWindowState.Normal;
            _form.BringToFront();
        }
        else
        {
            if (_form.WindowState == FormWindowState.Minimized) _form.WindowState = FormWindowState.Normal;
            _form.Activate();
        }
    }

    // ---- event wiring -----------------------------------------------------

    private void SinkEvt(string msg) { _guard.Sink.Evt(msg); }

    private void OnRaw(string line)
    {
        lock (_uiQ) { _uiQueue.Add(line); }
    }

    private void OnEvt(string line)
    {
        lock (_uiQ) { _uiQueue.Add("[事件] " + line); }
    }

    private void OnState(WatchState st, string detail)
    {
        _uiStateText = DescribeState(st, detail);
    }

    private void OnUrl(string url)
    {
        _currentUrlShown = url;
        if (_cfg.AutoOpenUI && !_openedOnce)
        {
            _openedOnce = true;
            ThreadPool.QueueUserWorkItem(delegate { OpenUrl(url); });
        }
    }

    private void OnImportant(string msg)
    {
        Notify(msg, 6000);
        lock (_uiQ) { _uiQueue.Add("[重要] " + msg); }
    }

    private string _currentUrlShown = "";

    private static string DescribeState(WatchState st, string detail)
    {
        switch (st)
        {
            case WatchState.Starting: return "正在启动服务…";
            case WatchState.Running: return "运行中 · 健康";
            case WatchState.Suspect: return "观察窗口：检测到插件/配置变更";
            case WatchState.RollingBack: return "正在回滚…";
            case WatchState.Stopped: return "服务已停止";
            case WatchState.MonitorOnly: return "仅监控外部实例";
            case WatchState.Failed: return "故障（已停止自动重启）";
            default: return st.ToString();
        }
    }

    private void RenderState()
    {
        if (_statusLabel == null) return;
        _statusLabel.Text = "状态：" + _uiStateText;
        string url = _currentUrlShown.Length > 0 ? _currentUrlShown : _guard.CurrentUrl;
        if (url != null && url.Length > 0) _urlLabel.Text = "界面地址（点击打开）：" + url;
        else _urlLabel.Text = "界面地址：尚未启动服务";
        _statusLabel.ForeColor = _uiStateText.IndexOf("故障", StringComparison.Ordinal) >= 0
            ? Color.Firebrick
            : (_uiStateText.IndexOf("运行", StringComparison.Ordinal) >= 0 ? Color.SeaGreen : Color.DimGray);
    }

    private void DrainQueue()
    {
        List<string> batch;
        lock (_uiQ)
        {
            if (_uiQueue.Count == 0)
            {
                RenderStateSafe();
                return;
            }
            batch = _uiQueue;
            _uiQueue = new List<string>();
        }
        if (_logBox != null && !_logBox.IsDisposed)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                foreach (string l in batch) sb.AppendLine(l);
                _logBox.AppendText(sb.ToString());
                // cap lines
                if (_logBox.Lines.Length > 4000)
                {
                    string[] lines = _logBox.Lines;
                    string[] tail = new string[2000];
                    Array.Copy(lines, lines.Length - 2000, tail, 0, 2000);
                    _logBox.Lines = tail;
                }
                _logBox.SelectionStart = _logBox.TextLength;
                _logBox.ScrollToCaret();
            }
            catch { }
        }
        RenderStateSafe();
    }

    private void RenderStateSafe()
    {
        try { RenderState(); }
        catch { }
    }

    // ---- actions ----------------------------------------------------------

    private void OpenUi()
    {
        string url = _guard.CurrentUrl;
        if (url == null || url.Length == 0)
        {
            MessageBox.Show("还没有可用的界面地址：请先“启动服务”，等日志出现 “dsh web: http://… ” 后再打开。", "DSH 桌面版");
            return;
        }
        OpenUrl(url);
    }

    private void OpenUrl(string url)
    {
        if (_directOpen)
        {
            DefaultBrowserOpen(url);
            return;
        }
        try
        {
            if (string.Equals(_cfg.UiMode, "edgeApp", StringComparison.OrdinalIgnoreCase))
            {
                string edge = LocateEdge();
                if (edge != null)
                {
                    ProcessStartInfo psi = new ProcessStartInfo(edge);
                    psi.Arguments = "--app=\"" + url + "\"";
                    psi.UseShellExecute = true;
                    Process.Start(psi);
                    SinkEvt("已在 Edge 应用窗口打开界面: " + url);
                    return;
                }
            }
            DefaultBrowserOpen(url);
        }
        catch (Exception ex)
        {
            SinkEvt("打开界面失败: " + ex.Message);
        }
    }

    private void DefaultBrowserOpen(string url)
    {
        try
        {
            Process.Start(url);
            SinkEvt("已在默认浏览器打开 Harness 网页: " + url);
        }
        catch (Exception ex)
        {
            SinkEvt("打开浏览器失败: " + ex.Message);
        }
    }

    private static string LocateEdge()
    {
        string[] cands = {
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) + "\\Microsoft\\Edge\\Application\\msedge.exe",
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) + "\\Microsoft\\Edge\\Application\\msedge.exe"
        };
        foreach (string c in cands) if (File.Exists(c)) return c;
        return null;
    }

    private static void OpenFolder(string dir)
    {
        try { Directory.CreateDirectory(dir); }
        catch { }
        try { Process.Start("explorer.exe", "\"" + dir + "\""); }
        catch { }
    }

    private string AppTitle()
    {
        if (_directOpen) return "DeepSeek Harness · 直接打开";
        if (_trayOnly) return "DSH AI 哨兵（运行中）";
        return "DSH 桌面版";
    }

    private void Notify(string text, int ms)
    {
        try
        {
            DateTime now = DateTime.UtcNow;
            if ((now - _lastBalloon).TotalMilliseconds < 800) return;
            _lastBalloon = now;
            _tray.ShowBalloonTip(ms, AppTitle(), text, ToolTipIcon.Info);
        }
        catch { }
    }

    private void Cleanup()
    {
        try
        {
            _uiTimer.Stop();
            _guard.StopSupervision();
            _guard.DisposeLogs();
            if (_tray != null) { _tray.Visible = false; _tray.Dispose(); }
            if (_form != null && !_form.IsDisposed) _form.Dispose();
        }
        catch { }
    }

    private void ShutdownAll()
    {
        try
        {
            _uiTimer.Stop();
            _guard.StopSupervision();
            _guard.DisposeLogs();
            if (_tray != null) { _tray.Visible = false; _tray.Dispose(); }
            if (_form != null && !_form.IsDisposed) _form.Dispose();
        }
        catch { }
        Application.Exit();
    }
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------
public static class Program
{
    private static Mutex _mutex;

    [STAThread]
    public static int Main(string[] args)
    {
        string exeDir = AppDomain.CurrentDomain.BaseDirectory;
        bool guard = false;
        bool direct = false;
        bool selftest = false;
        string selftestOut = exeDir + "selftest-result.txt";
        int portOverride = -1;
        string profileOverride = null;
        string dshHomeOverride = null;

        for (int i = 0; i < args.Length; i++)
        {
            string a = args[i];
            if (a == "--guard") guard = true;
            else if (a == "--direct") direct = true;
            else if (a == "--selftest")
            {
                selftest = true;
                if (i + 1 < args.Length && !args[i + 1].StartsWith("--")) selftestOut = args[++i];
            }
            else if (a == "--port" && i + 1 < args.Length) { int.TryParse(args[++i], out portOverride); }
            else if (a == "--profile" && i + 1 < args.Length) profileOverride = args[++i];
            else if (a == "--dshhome" && i + 1 < args.Length) dshHomeOverride = args[++i];
        }

        if (selftest) return SelfTest.Run(selftestOut);

        AppConfig cfg = AppConfig.Load(exeDir, guard || direct);
        if (portOverride > 0) cfg.Port = portOverride;
        if (profileOverride != null) { cfg.Profile = profileOverride; cfg.ProfileDir = cfg.DshHome + "profiles\\" + profileOverride; }
        if (dshHomeOverride != null) { cfg.DshHome = FlatConfig.NormalizeDir(dshHomeOverride); cfg.ProfileDir = cfg.DshHome + "profiles\\" + cfg.Profile; }

        bool trayOnly = guard || direct;
        string mutexName = "dsh-desktop-guard-mutex-" + (direct ? "direct" : (guard ? "guard" : "main"));
        bool createdNew;
        _mutex = new Mutex(true, mutexName, out createdNew);
        if (!createdNew)
        {
            if (!trayOnly)
                MessageBox.Show("DSH 桌面版已经在运行（窗口在任务栏/托盘）。", "DSH 桌面版");
            return 0;
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        using (HarnessApp app = new HarnessApp(cfg, trayOnly, direct))
        {
            Application.Run(app);
        }
        _mutex.ReleaseMutex();
        return 0;
    }
}

// ---------------------------------------------------------------------------
// Headless self tests (no UI, no external processes)
// ---------------------------------------------------------------------------
public static class SelfTest
{
    public static int Run(string outFile)
    {
        List<string> results = new List<string>();
        int fails = 0;
        Action<string, bool> check = delegate(string name, bool ok)
        {
            results.Add((ok ? "PASS " : "FAIL ") + name);
            if (!ok) fails++;
        };

        try { check("FlatConfig round-trip", T_Config()); }
        catch (Exception ex) { check("FlatConfig round-trip", false); results.Add("      ex: " + ex.Message); }
        try { check("Signature detects file change", T_Signature()); }
        catch (Exception ex) { check("Signature detects file change", false); results.Add("      ex: " + ex.Message); }
        try { check("Restore point create/rollback", T_Restore()); }
        catch (Exception ex) { check("Restore point create/rollback", false); results.Add("      ex: " + ex.Message); }
        try { check("Restore point rotation", T_Rotation()); }
        catch (Exception ex) { check("Restore point rotation", false); results.Add("      ex: " + ex.Message); }
        try { check("URL parse from dsh web line", T_Url()); }
        catch (Exception ex) { check("URL parse from dsh web line", false); results.Add("      ex: " + ex.Message); }
        try { check("ANSI strip", T_Ansi()); }
        catch (Exception ex) { check("ANSI strip", false); results.Add("      ex: " + ex.Message); }

        results.Add(fails == 0 ? "ALL TESTS PASSED" : (fails + " TEST(S) FAILED"));
        try { File.WriteAllLines(outFile, results.ToArray(), new UTF8Encoding(false)); }
        catch { }
        return fails == 0 ? 0 : 1;
    }

    private static string NewTempDir(string tag)
    {
        string dir = Path.Combine(Path.GetTempPath(), "dsh-selftest-" + tag + "-" + Guid.NewGuid().ToString("N").Substring(0, 8));
        Directory.CreateDirectory(dir);
        return dir;
    }

    private static bool T_Config()
    {
        string dir = NewTempDir("cfg");
        try
        {
            FlatConfig f = new FlatConfig();
            f.Set("name", "C:\\Users\\longdd\\.dsh");
            f.Set("port", "3080");
            f.Set("flag", "true");
            f.Set("s", "a\"b\\c");
            string path = dir + "\\c.json";
            f.Save(path);
            FlatConfig g = FlatConfig.Load(path);
            if (g.GetStr("name", "") != "C:\\Users\\longdd\\.dsh") return false;
            if (g.GetInt("port", -1) != 3080) return false;
            if (!g.GetBool("flag", false)) return false;
            if (g.GetStr("s", "") != "a\"b\\c") return false;
            return true;
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    private static bool T_Signature()
    {
        string dir = NewTempDir("sig");
        try
        {
            string pdir = dir + "\\profile\\";
            string hdir = dir + "\\home\\";
            Directory.CreateDirectory(pdir + "node_modules");
            Directory.CreateDirectory(hdir);
            File.WriteAllText(pdir + "package.json", "{\"name\":\"t\"}");
            File.WriteAllText(hdir + "settings.yaml", "a: 1");
            List<string> pf = new List<string> { "package.json" };
            List<string> hf = new List<string> { "settings.yaml" };
            string s1 = StateSignature.Compute(pdir, hdir, pf, hf);
            File.WriteAllText(pdir + "package.json", "{\"name\":\"t\",\"dependencies\":{\"x\":\"1\"}}");
            string s2 = StateSignature.Compute(pdir, hdir, pf, hf);
            if (s1 == s2) return false;
            // directory listing change must also be detected
            Directory.CreateDirectory(pdir + "node_modules\\@scope");
            string s3 = StateSignature.Compute(pdir, hdir, pf, hf);
            return s2 != s3;
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    private static bool T_Restore()
    {
        string dir = NewTempDir("rp");
        try
        {
            string pdir = dir + "\\profile\\";
            string hdir = dir + "\\home\\";
            Directory.CreateDirectory(pdir);
            Directory.CreateDirectory(hdir);
            File.WriteAllText(pdir + "package.json", "{\"bundles\":[\"a\"]}");
            File.WriteAllText(pdir + "cordis.patch.yml", "[]\n");
            File.WriteAllText(hdir + "settings.yaml", "old: 1");
            List<string> pf = RestorePointStore.ProfileStateFileNames();
            List<string> hf = new List<string> { "settings.yaml" };

            // fake AppConfig-shaped store (store appends "restore-points" to DataDir)
            FlatConfig fc = new FlatConfig();
            RestorePointStore store = new RestorePointStoreShim(dir + "\\data", pdir, hdir, pf, hf, 5);

            string rp = store.Create("test", "t");
            if (!File.Exists(rp + "\\P__package.json")) return false;
            if (!File.Exists(rp + "\\H__settings.yaml")) return false;

            // mutate
            File.WriteAllText(pdir + "package.json", "{\"bundles\":[\"a\",\"bad-plugin\"]}");
            File.WriteAllText(hdir + "settings.yaml", "new: 2");

            List<string> restored = store.Rollback(rp);
            if (restored.Count < 2) return false;
            string pkg = File.ReadAllText(pdir + "package.json");
            string set = File.ReadAllText(hdir + "settings.yaml");
            return pkg.IndexOf("bad-plugin", StringComparison.Ordinal) < 0 && set.IndexOf("old: 1", StringComparison.Ordinal) >= 0;
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    private static bool T_Rotation()
    {
        string dir = NewTempDir("rot");
        try
        {
            string pdir = dir + "\\profile\\";
            string hdir = dir + "\\home\\";
            Directory.CreateDirectory(pdir);
            Directory.CreateDirectory(hdir);
            File.WriteAllText(pdir + "package.json", "{}");
            List<string> pf = RestorePointStore.ProfileStateFileNames();
            List<string> hf = new List<string> { };
            RestorePointStore store = new RestorePointStoreShim(dir + "\\data", pdir, hdir, pf, hf, 3);
            for (int i = 0; i < 6; i++)
            {
                Thread.Sleep(1100); // ensure distinct second-level timestamps
                store.Create("rot-" + i, "");
            }
            List<string> pts = store.ListPoints();
            return pts.Count == 3;
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    private static bool T_Url()
    {
        string u = Ansi.FindDshUrl("dsh web: http://127.0.0.1:3080/?token=AbC123");
        if (u != "http://127.0.0.1:3080/?token=AbC123") return false;
        u = Ansi.FindDshUrl("some noise then dsh web:  http://127.0.0.1:3080/ (LAN: http://192.168.1.2:3080/?token=x)");
        return u != null && u.IndexOf("token=x", StringComparison.Ordinal) >= 0;
    }

    private static bool T_Ansi()
    {
        string s = Ansi.Strip("a\u001B[31mb\u001B[0mc");
        return s == "abc";
    }

    // small shim so the store can be tested against arbitrary dirs
    private sealed class RestorePointStoreShim : RestorePointStore
    {
        public RestorePointStoreShim(string root, string profileDir, string homeDir, List<string> pf, List<string> hf, int keep)
            : base(Shim(root, profileDir, homeDir, pf, hf, keep)) { }

        private static AppConfig Shim(string root, string pdir, string hdir, List<string> pf, List<string> hf, int keep)
        {
            AppConfig c = new AppConfig();
            c.DataDir = root;
            c.ProfileDir = pdir;
            c.DshHome = hdir;
            c.KeepRestorePoints = keep;
            return c;
        }
    }
}
